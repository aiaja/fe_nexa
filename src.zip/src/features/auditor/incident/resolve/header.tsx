"use client"
import { ArrowLeft, Info } from "lucide-react"
import { useRouter } from "next/navigation"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface ResolveHeaderProps {
  caseId: string
}

export function ResolveHeader({ caseId }: ResolveHeaderProps) {
  const router = useRouter()

  const formattedCaseId = caseId && caseId.startsWith("Case ") ? caseId : `Case ${caseId || ""}`

  return (
    <div className="mb-6">
      {/* Back Button and Title */}
      <div className="flex items-center gap-4 mb-4">
        <button
          type="button"
          onClick={() => router.back()}
          aria-label="Go back"
          title="Go back"
          className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>

        <div>
          <h1 className="text-2xl font-bold text-gray-900">Resolve Case</h1>
          <p className="text-sm text-gray-500 mt-1">{formattedCaseId}</p>
        </div>
      </div>

      <Alert className="bg-blue-50 border-blue-200">
        <Info className="h-4 w-4 text-blue-600" />
        <AlertTitle className="text-blue-900">
          Choose the most accurate resolution type based on your investigation
        </AlertTitle>
        <AlertDescription className="text-blue-700">
          Ensure supporting data and evidence are reviewed before finalizing the case
        </AlertDescription>
      </Alert>
    </div>
  )
}
