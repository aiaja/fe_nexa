"use client"

import { useState } from "react"
import { ResolveHeader } from "./header"
import { ResolutionCard } from "./resolution-card"
import { NotesSection } from "./notes-section"
import { ActionButtons } from "./action-buttons"
import type { ResolutionOption } from "@/interface/auditor/incident-reports/resolve"

interface ResolvePageProps {
  caseId: string
  options: ResolutionOption[]
}

export default function ResolvePage({ caseId, options }: ResolvePageProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [notes, setNotes] = useState("")

  const handleSubmit = () => {
    console.log("Submitting resolution:", {
      caseId,
      resolution: selectedOption,
      notes,
    })
  }

  return (
    <div className="flex flex-1 flex-col bg-gray-50 p-6">
      <div className="w-full max-w-4xl mx-auto">
        <ResolveHeader caseId={caseId} />

        <div className="grid grid-cols-2 gap-4 mb-6">
          {options.map((option) => (
            <ResolutionCard
              key={option.resolutionType}
              option={option}
              isSelected={selectedOption === option.resolutionType}
              onClick={() => setSelectedOption(option.resolutionType)}
            />
          ))}
        </div>

        <div className="mb-6">
          <NotesSection notes={notes} onChange={setNotes} />
        </div>

        <ActionButtons caseId={caseId} selectedOption={selectedOption} notes={notes} onSubmit={handleSubmit} />
      </div>
    </div>
  )
}