"use client"

import React from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"

interface ActionButtonsProps {
  caseId: string
  selectedOption: string | null
  notes: string
  onSubmit: () => void
}

export function ActionButtons({ caseId, selectedOption, notes, onSubmit }: ActionButtonsProps) {
  const router = useRouter()
  const [isSubmitting, setIsSubmitting] = React.useState(false)

  const handleSubmit = async () => {
    if (!selectedOption) return

    setIsSubmitting(true)

    // Simulate API call
    setTimeout(() => {
      onSubmit()
      setIsSubmitting(false)

      // Show success message
      alert("Resolution submitted successfully!")

      router.push("/auditor/incident")
    }, 1000)
  }

  const handleCancel = () => {
    router.back()
  }

  return (
    <div className="flex gap-3 justify-end pt-4">
      <Button onClick={handleCancel} disabled={isSubmitting} variant="outline">
        Cancel
      </Button>
      <Button
        onClick={handleSubmit}
        disabled={!selectedOption || isSubmitting}
        className="bg-blue-600 hover:bg-blue-700"
      >
        {isSubmitting ? "Submitting..." : "Update Resolution"}
      </Button>
    </div>
  )
}
