"use client";

import React from 'react';
import { ReportsPage } from './reports-page';
import { ReportCase } from '@/interface/auditor/reports';

// Mock data - replace with actual API call
const mockCases: ReportCase[] = [
  {
    id: 'report-001',
    caseId: 'A-2024-0847',
    dateTime: '06 Nov 2024, 14:32',
    fleetId: 'F-001',
    fleetName: 'Volvo FH16',
    driverId: 'D-001',
    driverName: 'Ahmad Suryanto',
    category: 'SUDDEN DROP',
    severity: 'CRITICAL',
    status: 'RESOLVED',
    resolution: 'confirmed_theft',
    notes: 'Pencurian BBM terverifikasi. GPS data menunjukkan driver berhenti di SPBU resmi.',
  },
  {
    id: 'report-002',
    caseId: 'A-2024-0848',
    dateTime: '06 Nov 2024, 11:15',
    fleetId: 'F-002',
    fleetName: 'Mercedes Actros',
    driverId: 'D-002',
    driverName: 'Bambang Wibowo',
    category: 'OUT OF ZONE',
    severity: 'HIGH',
    status: 'RESOLVED',
    resolution: 'driver_behavior',
    notes: 'Driver menyimpang dari rute yang ditentukan.',
  },
  {
    id: 'report-003',
    caseId: 'A-2024-0845',
    dateTime: '08 Nov 2024, 09:20',
    fleetId: 'F-003',
    fleetName: 'Canyo Prasetyo',
    driverId: 'D-003',
    driverName: 'Canyo Prasetyo',
    category: 'OVERCONSUMPTION',
    severity: 'MEDIUM',
    status: 'RESOLVED',
    resolution: 'confirmed_theft',
    notes: 'Salah rute',
  },
  {
    id: 'report-004',
    caseId: 'A-2024-0842',
    dateTime: '08 Nov 2024, 08:45',
    fleetId: 'F-004',
    fleetName: 'Dedi Kuriawan',
    driverId: 'D-004',
    driverName: 'Dedi Kuriawan',
    category: 'SUDDEN DROP',
    severity: 'CRITICAL',
    status: 'RESOLVED',
    resolution: 'fleet_issue',
    notes: 'Mesin mali',
  },
  {
    id: 'report-005',
    caseId: 'A-2024-0841',
    dateTime: '08 Nov 2024, 08:45',
    fleetId: 'F-004',
    fleetName: 'Dedi Kuriawan',
    driverId: 'D-004',
    driverName: 'Dedi Kuriawan',
    category: 'SENSOR MALFUNCTION',
    severity: 'MEDIUM',
    status: 'RESOLVED',
    resolution: 'no_violation',
    notes: 'Ban bocor',
  },
];

export default function Page() {
  return <ReportsPage initialCases={mockCases} />;
}
