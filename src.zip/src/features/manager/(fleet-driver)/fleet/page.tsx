// import React from "react";
// import { Search, Funnel } from "lucide-react";
// import { Input } from "@/components/ui/input";

// function FleetPage() {
//   return (
//     <>
//       <div className="text-xl font-semibold">Fleet Management</div>
//       <div className="inline-flex gap-4">
//         <div className="relative flex-1">
//           <Input
//             type="text"
//             placeholder="Search Fleet"
//             // value={searchQuery}
//             // onChange={e => setSearchQuery(e.target.value)}
//             className="focus-visible:ring-0 focus-visible:border-[#0047AB]"
//           />
//           <Search className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
//         </div>
//         <div className="relative flex-1">
//           <Input
//             type="text"
//             placeholder="Filter by"
//             className="focus-visible:ring-0 focus-visible:border-[#0047AB]"
//           />
//           <Funnel className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" />
//         </div>
//       </div>
//     </>
//   );
// }

// export default FleetPage;
