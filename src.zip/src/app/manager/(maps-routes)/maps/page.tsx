import React from 'react'
import LiveMaps from '@/features/manager/(maps-routes)/maps/LiveMaps'

function page() {
  return (
    <div><LiveMaps></LiveMaps></div>
  )
}

export default page