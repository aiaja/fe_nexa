import React from 'react'
import FleetAnalyticsPage from '@/features/auditor/(analytics)/fleet/fleet-analytics-page'

export default function Page() {
  return <FleetAnalyticsPage />
}
