"use client"

import { DriverAnalyticsPage } from "@/features/auditor/(analytics)/driver/driver-analytics-page"

export default function DriverAnalyticsRoute() {
  return <DriverAnalyticsPage />
}
