export interface DeliveryHistory {
    date: Date;
    id: string;                    
  name: string;            
  fleet_id: string;
  location: string;
}
