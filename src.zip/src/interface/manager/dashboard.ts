export interface DashboardOverview {
  title: string;
  value: string;
}

export interface DashboardAnomaly {
  title: string;
  value: string;
  description: string;
}