import { IncidentReport } from "@/interface/auditor/incident-reports/incidents";

export const IncidentsData: IncidentReport[] = [
  {
    id: "INC-0847",
    caseNumber: "A-2024-0847",
    zoneId: "ZONE-01",
    title: "Suspected Fuel Theft - Truck #F-001",
    location: "Unknown",
    category: "SUDDEN DROP",
    severity: "CRITICAL",
    confidence: "92%",
    detectionDate: "06 Nov 2024, 14:32 WIB",
    driver: {
      driverId: "D-001",
      name: "Ahmad Suryanto",
    },
    fleet: {
      fleetId: "F-001",
      model: "Hero Ranger 2019",
    },
    keyIndicators: [
      "Fuel drop: 45L in 8 minutes (expected: 0L)",
      "Location: Outside designated route",
      "GPS signal lost for 12 minutes",
      "3rd incident this month for this driver",
    ],
  },

  {
    id: "INC-0852",
    caseNumber: "A-2024-0852",
    zoneId: "ZONE-02",
    title: "Out of Zone Activity - Truck #F-002",
    location: "Unknown",
    category: "OUT OF ZONE",
    severity: "HIGH",
    confidence: "81%",
    detectionDate: "07 Nov 2024, 08:15 WIB",
    driver: {
      driverId: "D-002",
      name: "Dika Kusuma",
    },
    fleet: {
      fleetId: "F-003",
      model: "Isuzu Giga 2021",
    },
    keyIndicators: [
      "Fuel level decreased by 35L",
      "Vehicle outside authorized zone for 28 minutes",
      "Occurred during night shift",
    ],
  },

  {
    id: "INC-0853",
    caseNumber: "A-2024-0853",
    zoneId: "ZONE-03",
    title: "Overconsumption Pattern - Truck #F-007",
    location: "Unknown",
    category: "OVERCONSUMPTION",
    severity: "HIGH",
    confidence: "87%",
    detectionDate: "07 Nov 2024, 10:30 WIB",
    driver: {
      driverId: "D-003",
      name: "Ahmad Suryanto",
    },
    fleet: {
      fleetId: "F-001",
      model: "Hero Ranger 2019",
    },
    keyIndicators: [
      "Fuel consumption 40% above normal",
      "Pattern detected over 3 consecutive trips",
      "No maintenance records in last 2 months",
    ],
  },

  {
    id: "INC-0854",
    caseNumber: "A-2024-0854",
    zoneId: "ZONE-01",
    title: "Fleet Sensor Malfunction - Truck #F-004",
    location: "Unknown",
    category: "SUDDEN DROP",
    severity: "MEDIUM",
    confidence: "68%",
    detectionDate: "07 Nov 2024, 13:20 WIB",
    driver: {
      driverId: "D-004",
      name: "Kurniawan Adi",
    },
    fleet: {
      fleetId: "F-001",
      model: "Hero Ranger 2019",
    },
    keyIndicators: [
      "Fuel sensor reading inconsistent",
      "Multiple sensor errors detected",
      "Temperature fluctuation within normal range",
      "3rd incident this month for this driver",
    ],
  },

  {
    id: "INC-0855",
    caseNumber: "A-2024-0855",
    zoneId: "ZONE-04",
    title: "Out of Zone - Truck #F-004",
    location: "Unknown",
    category: "OUT OF ZONE",
    severity: "CRITICAL",
    confidence: "90%",
    detectionDate: "07 Nov 2024, 14:50 WIB",
    driver: {
      driverId: "D-001",
      name: "Ahmad Suryanto",
    },
    fleet: {
      fleetId: "F-001",
      model: "Hero Ranger 2019",
    },
    keyIndicators: [
      "Vehicle detected 50km from authorized route",
      "GPS tracking active",
      "Fuel level normal",
      "No communication from driver",
    ],
  },
];
