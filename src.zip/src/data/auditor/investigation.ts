import { InvestigationData } from "@/interface/auditor/incident-reports/investigation";

export const investigationData: Record<string, InvestigationData> = {
  "A-2024-0847": {
    summary: {
      caseNumber: "A-2024-0847",
      type: "Fuel Theft",
      fleetId: "F-001",
      driverId: "D-001",
      date: "06 Nov 2024, 14:32 WIB",
      severity: "CRITICAL",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0847",
        time: "13:00",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Refueled: 140L", "Tank: 95% (180L)"],
      },
      {
        id: "2",
        incidentId: "A-2024-0847",
        time: "13:45",
        location: "Checkpoint 1 (Route A)",
        saverity: "MEDIUM",
        details: ["Tank: 88% (135L)", "Speed: 65 km/h"],
      },
      {
        id: "3",
        incidentId: "A-2024-0847",
        time: "14:20",
        location: "Anomaly Location (Route KM 57)",
        saverity: "CRITICAL",
        details: [
          "GPS Signal Lost: 12 minutes",
          "Suspected unauthorized stop",
          "Fuel missing: 45L",
        ],
      },
    ],
  },

  "A-2024-0852": {
    summary: {
      caseNumber: "A-2024-0852",
      type: "Out of Zone",
      fleetId: "F-003",
      driverId: "D-002",
      date: "07 Nov 2024, 08:15 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0852",
        time: "07:30",
        location: "Depot B",
        saverity: "MEDIUM",
        details: ["Departure from depot", "Tank: 92% (165L)"],
      },
      {
        id: "2",
        incidentId: "A-2024-0852",
        time: "08:05",
        location: "Route B (authorized)",
        saverity: "MEDIUM",
        details: ["Normal route", "Speed: 60 km/h"],
      },
      {
        id: "3",
        incidentId: "A-2024-0852",
        time: "08:15",
        location: "Industrial Zone C (Unauthorized Area)",
        saverity: "CRITICAL",
        details: [
          "Vehicle outside authorized zone",
          "Detected during night shift",
          "Fuel drop: 35L total",
        ],
      },
    ],
  },

  "A-2024-0853": {
    summary: {
      caseNumber: "A-2024-0853",
      type: "Overconsumption",
      fleetId: "F-001",
      driverId: "D-003",
      date: "07 Nov 2024, 10:30 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0853",
        time: "09:00",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Tank: 94% (170L)", "Start of trip"],
      },
      {
        id: "2",
        incidentId: "A-2024-0853",
        time: "10:00",
        location: "Route C",
        saverity: "HIGH",
        details: [
          "Fuel usage 40% above normal",
          "Aggressive acceleration detected",
        ],
      },
      {
        id: "3",
        incidentId: "A-2024-0853",
        time: "10:30",
        location: "Route C Sector 3",
        saverity: "CRITICAL",
        details: [
          "Overconsumption pattern detected",
          "Suggested engine check overdue",
        ],
      },
    ],
  },

  "A-2024-0854": {
    summary: {
      caseNumber: "A-2024-0854",
      type: "Sensor Malfunction",
      fleetId: "F-001",
      driverId: "D-004",
      date: "07 Nov 2024, 13:20 WIB",
      severity: "CRITICAL",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0854",
        time: "12:40",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Departure", "Tank: 89%"],
      },
      {
        id: "2",
        incidentId: "A-2024-0854",
        time: "13:05",
        location: "Route D",
        saverity: "HIGH",
        details: ["Sensor reading fluctuating", "Error code: FUEL-ERR-02"],
      },
      {
        id: "3",
        incidentId: "A-2024-0854",
        time: "13:20",
        location: "Route D KM 22",
        saverity: "CRITICAL",
        details: ["Fuel sensor inconsistent", "Multiple anomalies recorded"],
      },
    ],
  },

  "A-2024-0855": {
    summary: {
      caseNumber: "A-2024-0855",
      type: "Out of Zone",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 14:50 WIB",
      severity: "CRITICAL",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0855",
        time: "14:00",
        location: "Authorized Route E",
        saverity: "MEDIUM",
        details: ["Route normal", "Speed 60 km/h"],
      },
      {
        id: "2",
        incidentId: "A-2024-0855",
        time: "14:35",
        location: "Near Route Exit E",
        saverity: "HIGH",
        details: ["Deviation detected"],
      },
      {
        id: "3",
        incidentId: "A-2024-0855",
        time: "14:50",
        location: "50 km Off Route",
        saverity: "CRITICAL",
        details: [
          "Vehicle 50km off authorized route",
          "GPS active but no driver communication",
        ],
      },
    ],
  },

  "A-2024-0856": {
    summary: {
      caseNumber: "A-2024-0856",
      type: "driverId Behavior",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 15:30 WIB",
      severity: "MEDIUM",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0856",
        time: "14:45",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Departure", "Tank: 92%"],
      },
      {
        id: "2",
        incidentId: "A-2024-0856",
        time: "15:10",
        location: "Route F",
        saverity: "HIGH",
        details: ["Aggressive acceleration", "Hard braking events detected"],
      },
      {
        id: "3",
        incidentId: "A-2024-0856",
        time: "15:30",
        location: "Route F Sector 4",
        saverity: "HIGH",
        details: ["Fuel efficiency decreased", "Behavior anomaly"],
      },
    ],
  },

  "A-2024-0857": {
    summary: {
      caseNumber: "A-2024-0857",
      type: "Overconsumption",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 16:10 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0857",
        time: "15:20",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Departure", "Tank: 89%"],
      },
      {
        id: "2",
        incidentId: "A-2024-0857",
        time: "15:50",
        location: "Route H",
        saverity: "HIGH",
        details: ["Fuel consumption 35% above baseline"],
      },
      {
        id: "3",
        incidentId: "A-2024-0857",
        time: "16:10",
        location: "Route H KM 12",
        saverity: "CRITICAL",
        details: [
          "High consumption over daily average",
          "Possible driver-related issue",
        ],
      },
    ],
  },

  "A-2024-0858": {
    summary: {
      caseNumber: "A-2024-0858",
      type: "Sudden Drop",
      fleetId: "F-001",
      driverId: "D-001",
      date: "08 Nov 2024, 07:25 WIB",
      severity: "CRITICAL",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0858",
        time: "06:40",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Departure", "Tank: 97%"],
      },
      {
        id: "2",
        incidentId: "A-2024-0858",
        time: "07:15",
        location: "Route J",
        saverity: "MEDIUM",
        details: ["Normal movement"],
      },
      {
        id: "3",
        incidentId: "A-2024-0858",
        time: "07:25",
        location: "Route J KM 34",
        saverity: "CRITICAL",
        details: [
          "Fuel dropped 58L in 5 minutes",
          "No refueling station nearby",
        ],
      },
    ],
  },

  "A-2024-0859": {
    summary: {
      caseNumber: "A-2024-0859",
      type: "Overconsumption",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 15:30 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0859",
        time: "14:45",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Departure", "Tank: 94%"],
      },
      {
        id: "2",
        incidentId: "A-2024-0859",
        time: "15:10",
        location: "Route L",
        saverity: "HIGH",
        details: ["Consumption +28% above normal"],
      },
      {
        id: "3",
        incidentId: "A-2024-0859",
        time: "15:30",
        location: "Route L Sector 2",
        saverity: "CRITICAL",
        details: ["Consistent 5-day pattern"],
      },
    ],
  },

  "A-2024-0860": {
    summary: {
      caseNumber: "A-2024-0860",
      type: "Out of Zone",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 08:15 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0860",
        time: "07:40",
        location: "Route M",
        saverity: "MEDIUM",
        details: ["Normal movement"],
      },
      {
        id: "2",
        incidentId: "A-2024-0860",
        time: "07:55",
        location: "Route M Exit",
        saverity: "HIGH",
        details: ["Deviation detected"],
      },
      {
        id: "3",
        incidentId: "A-2024-0860",
        time: "08:15",
        location: "30 km Outside Authorized Zone",
        saverity: "CRITICAL",
        details: ["Vehicle outside zone for 45 minutes"],
      },
    ],
  },

  "A-2024-0861": {
    summary: {
      caseNumber: "A-2024-0861",
      type: "Sudden Drop",
      fleetId: "F-001",
      driverId: "D-001",
      date: "08 Nov 2024, 07:25 WIB",
      severity: "CRITICAL",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0861",
        time: "06:50",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Tank full", "Departure"],
      },
      {
        id: "2",
        incidentId: "A-2024-0861",
        time: "07:10",
        location: "Route Z",
        saverity: "MEDIUM",
        details: ["Normal movement"],
      },
      {
        id: "3",
        incidentId: "A-2024-0861",
        time: "07:25",
        location: "Route Z KM 18",
        saverity: "CRITICAL",
        details: [
          "Fuel drop 52L in 7 minutes",
          "GPS intermittent",
        ],
      },
    ],
  },

  "A-2024-0862": {
    summary: {
      caseNumber: "A-2024-0862",
      type: "Overconsumption",
      fleetId: "F-001",
      driverId: "D-001",
      date: "07 Nov 2024, 15:30 WIB",
      severity: "HIGH",
    },
    timeline: [
      {
        id: "1",
        incidentId: "A-2024-0862",
        time: "14:30",
        location: "Depot A",
        saverity: "MEDIUM",
        details: ["Full tank", "Departure"],
      },
      {
        id: "2",
        incidentId: "A-2024-0862",
        time: "15:00",
        location: "Route N",
        saverity: "HIGH",
        details: ["Fuel usage +32% from weekly average"],
      },
      {
        id: "3",
        incidentId: "A-2024-0862",
        time: "15:30",
        location: "Route N Sector 4",
        saverity: "CRITICAL",
        details: ["Possible fuel leak"],
      },
    ],
  },
};
