Kumpulan komponen UI GLOBAL yang dapat digunakan kembali di seluruh halaman.
Contoh: tombol, form input, modal, tabel, kartu menu, dsb.